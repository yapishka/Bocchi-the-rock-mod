# Bocchi Companion — Minecraft Java 1.21.11 / Fabric

This project contains a Hitori-inspired companion entity, an original generated pixel texture, a custom model layer with added hair/collar geometry, following behavior, combat assistance, and a conservative exposed-ore scanning/mining prototype.

## Current feature design
- Custom entity ID: `bocchi_companion:hitori`
- Summon command: `/summon bocchi_companion:hitori`
- Hitori is intended to spawn beside each player on their first join.
- Right-click Hitori to set yourself as her owner; crouch + right-click transfers her stored items to your inventory.
- Follows the owner and wanders when idle.
- Helps attack monsters that have recently attacked the owner, or enemies the owner just hit.
- Periodically searches a small radius for exposed ore blocks and stores their drops in a persistent 27-slot inventory.
- Picks up nearby dropped items (including mob drops) into that inventory.
- Sneak + right-click transfers stored items into the player's inventory.
- Uses a generated 64x64 pink-hair / blue-eye / pink-hoodie pixel texture and a custom model layer with extra hair-lock, fringe, and hoodie-collar geometry.

## Build
- Java 21
- Minecraft Java 1.21.11
- Fabric Loader 0.18.1
- Fabric API 0.141.4+1.21.11
- Gradle wrapper is not included in this archive. Open the project in IntelliJ IDEA with Gradle support or install a compatible Gradle and run `gradle build`.

## Important status
This is a **development build/source project, not a verified compiled `.jar`**. This environment has no network/DNS access and no installed Gradle, so dependency resolution and an actual Minecraft launch test could not be performed here. Because Minecraft 1.21.11 has recent API changes, you should run the build and resolve any mapping/API issues in a connected Java 21 + Gradle environment before using it in a world.

Ore mining is intentionally limited to nearby exposed ores and does not tunnel through terrain. The drops are currently stored internally and do not yet have a GUI/command to retrieve them. This avoids destructive mining and is a clear next feature to add.


## New in 0.3.0 (source update)
- On player join, the mod attempts to spawn Hitori nearby if no Hitori exists within 128 blocks.
- Right-click Hitori to open a 27-slot chest-style inventory; Shift + right-click only shows a short companion message.
- Ore drops are inserted into her inventory. If it is full, excess drops are left in the world rather than silently deleted.
- The inventory is currently entity-held and is saved with the entity only if the container is serialized; persistent inventory serialization is still a follow-up requirement before treating this as a release-ready build.

## Сборка через GitHub Actions

В проект добавлен workflow `.github/workflows/build.yml`. После загрузки файлов проекта в репозиторий GitHub:

1. Открой вкладку **Actions**.
2. Выбери **Build Fabric mod** и нажми **Run workflow** (или сделай push файлов — сборка запустится автоматически).
3. Открой завершившийся запуск. Если сборка прошла успешно, внизу страницы в разделе **Artifacts** появится `bocchi-companion-1.21.11` — скачай архив и извлеки из него `.jar`.

Workflow использует Java 21 и устанавливает Gradle на стороне GitHub, поэтому Gradle Wrapper в проекте не требуется. Если сборка завершится ошибкой, открой шаг **Build mod JAR** и посмотри журнал: workflow не исправляет ошибки исходного кода автоматически.

Важно: проект пока не проверен успешной сборкой и запуском в Minecraft. Полученный JAR нужно протестировать в отдельном профиле Minecraft 1.21.11 с Fabric Loader и Fabric API соответствующих версий.
