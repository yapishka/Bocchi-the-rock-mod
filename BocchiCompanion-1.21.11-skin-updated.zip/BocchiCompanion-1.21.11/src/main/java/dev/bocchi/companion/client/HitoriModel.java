package dev.bocchi.companion.client;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;

/**
 * Custom Hitori model layer based on the humanoid rig, with additional hair geometry.
 * The skin texture is original and included in assets/bocchi_companion/textures/entity/hitori.png.
 */
public final class HitoriModel extends HumanoidModel<HumanoidRenderState> {
    public HitoriModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        PartDefinition hat = root.getChild("hat");

        // Long pink side locks and a blocky fringe; these are real model cuboids,
        // not painted-on pixels. The texture uses the matching outer head UV region.
        hat.addOrReplaceChild("left_lock",
                CubeListBuilder.create().texOffs(32, 8)
                        .addBox(2.0F, -1.0F, -3.5F, 2.0F, 7.0F, 4.0F, new CubeDeformation(0.05F)),
                net.minecraft.client.model.geom.PartPose.offset(0.0F, 0.0F, 0.0F));
        hat.addOrReplaceChild("right_lock",
                CubeListBuilder.create().texOffs(48, 8)
                        .addBox(-4.0F, -1.0F, -3.5F, 2.0F, 7.0F, 4.0F, new CubeDeformation(0.05F)),
                net.minecraft.client.model.geom.PartPose.offset(0.0F, 0.0F, 0.0F));
        hat.addOrReplaceChild("fringe",
                CubeListBuilder.create().texOffs(40, 0)
                        .addBox(-4.0F, -8.5F, -4.0F, 8.0F, 3.0F, 1.0F, new CubeDeformation(0.1F)),
                net.minecraft.client.model.geom.PartPose.offset(0.0F, 0.0F, 0.0F));

        // Add a little hoodie collar on the torso.
        root.getChild("body").addOrReplaceChild("hoodie_collar",
                CubeListBuilder.create().texOffs(20, 20)
                        .addBox(-4.5F, -1.0F, -2.5F, 9.0F, 3.0F, 5.0F, new CubeDeformation(0.15F)),
                net.minecraft.client.model.geom.PartPose.offset(0.0F, 0.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }
}
