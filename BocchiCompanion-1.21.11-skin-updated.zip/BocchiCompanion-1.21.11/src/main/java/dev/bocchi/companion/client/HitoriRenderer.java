package dev.bocchi.companion.client;

import dev.bocchi.companion.BocchiCompanion;
import dev.bocchi.companion.entity.HitoriEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;

public final class HitoriRenderer extends MobRenderer<HitoriEntity, HumanoidRenderState, HitoriModel> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(
            BocchiCompanion.MOD_ID, "textures/entity/hitori.png");

    public HitoriRenderer(EntityRendererProvider.Context context) {
        super(context, new HitoriModel(context.bakeLayer(BocchiCompanionClient.HITORI_LAYER)), 0.35F);
    }

    @Override
    public HumanoidRenderState createRenderState() {
        return new HumanoidRenderState();
    }

    @Override
    public Identifier getTextureLocation(HumanoidRenderState state) {
        return TEXTURE;
    }
}
