package dev.bocchi.companion.entity;

import dev.bocchi.companion.BocchiCompanion;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * Companion AI. Inventory persists in entity NBT. Right-click opens a simple
 * vanilla container menu in a future client pass; currently sneaking + right-click
 * transfers the stored items to the owner.
 */
public class HitoriEntity extends PathfinderMob {
    private static final int INVENTORY_SIZE = 27;
    private final List<ItemStack> companionInventory = new ArrayList<>();
    private Player owner;
    private int miningCooldown;
    private int pickupCooldown;
    private int sleepCheckCooldown;
    private boolean sleepingBesideOwner;
    private BlockPos sleepBedPos;

    public HitoriEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        for (int i = 0; i < INVENTORY_SIZE; i++) companionInventory.add(ItemStack.EMPTY);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 32.0)
                .add(Attributes.MOVEMENT_SPEED, 0.30)
                .add(Attributes.ATTACK_DAMAGE, 5.0)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.15);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15, true));
        goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.15, 3.0F, 1.5F));
        goalSelector.addGoal(7, new RandomStrollGoal(this, 0.8));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, 10, true, false,
                monster -> owner != null && monster.getTarget() == owner));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (level().isClientSide()) return InteractionResult.SUCCESS;
        if (owner == null) owner = player;

        if (player.isShiftKeyDown()) {
            int moved = transferInventoryTo(player);
            player.displayClientMessage(Component.literal(
                    moved > 0 ? "Хитори отдала тебе добычу: " + moved + " предметов."
                            : "У Хитори пока нет добычи или у тебя нет места."), true);
        } else {
            owner = player;
            player.displayClientMessage(Component.literal(
                    "Хитори: Я буду рядом! Присядь и нажми ПКМ, чтобы забрать мою добычу."), true);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide()) return;

        if (owner == null || !owner.isAlive() || owner.level() != level()) {
            owner = level().getNearestPlayer(this, 16.0);
        }

        if (miningCooldown > 0) miningCooldown--;
        if (pickupCooldown > 0) pickupCooldown--;
        if (sleepCheckCooldown > 0) sleepCheckCooldown--;

        if (owner != null && owner.isAlive() && distanceToSqr(owner) < 32 * 32) {
            LivingEntity threat = owner.getLastHurtByMob();
            if (threat != null && threat.isAlive() && distanceToSqr(threat) < 12 * 12) setTarget(threat);
            LivingEntity attacked = owner.getLastHurtMob();
            if (attacked != null && attacked.isAlive() && distanceToSqr(attacked) < 8 * 8) setTarget(attacked);

            if (pickupCooldown <= 0) {
                pickUpNearbyDrops();
                pickupCooldown = 10;
            }
            if (miningCooldown <= 0 && getTarget() == null && !sleepingBesideOwner) {
                tryMineNearbyOre();
                miningCooldown = 80;
            }
            if (sleepCheckCooldown <= 0) {
                trySleepBesideOwner();
                sleepCheckCooldown = 20;
            }
        }

        if (sleepingBesideOwner && (owner == null || !owner.isSleeping())) {
            wakeFromBed();
        }
    }

    private void pickUpNearbyDrops() {
        if (level().isClientSide()) return;
        AABB box = getBoundingBox().inflate(3.5);
        for (var entity : level().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class, box)) {
            if (!entity.isAlive() || entity.getItem().isEmpty()) continue;
            ItemStack stack = entity.getItem();
            int inserted = insertStack(stack);
            if (inserted > 0) {
                if (stack.isEmpty()) entity.discard();
                else entity.setItem(stack);
            }
        }
    }

    private int insertStack(ItemStack incoming) {
        int original = incoming.getCount();
        for (int i = 0; i < companionInventory.size() && !incoming.isEmpty(); i++) {
            ItemStack current = companionInventory.get(i);
            if (!current.isEmpty() && ItemStack.isSameItemSameComponents(current, incoming)) {
                int max = Math.min(current.getMaxStackSize(), 64);
                int room = max - current.getCount();
                if (room > 0) {
                    int amount = Math.min(room, incoming.getCount());
                    current.grow(amount);
                    incoming.shrink(amount);
                }
            }
        }
        for (int i = 0; i < companionInventory.size() && !incoming.isEmpty(); i++) {
            if (companionInventory.get(i).isEmpty()) {
                int amount = Math.min(incoming.getCount(), incoming.getMaxStackSize());
                companionInventory.set(i, incoming.copyWithCount(amount));
                incoming.shrink(amount);
            }
        }
        return original - incoming.getCount();
    }

    private int transferInventoryTo(Player player) {
        int moved = 0;
        for (ItemStack stack : companionInventory) {
            if (stack.isEmpty()) continue;
            ItemStack remainder = player.getInventory().add(stack.copy());
            moved += stack.getCount() - remainder.getCount();
            if (remainder.isEmpty()) stack.setCount(0);
            else stack.setCount(remainder.getCount());
        }
        return moved;
    }

    private void tryMineNearbyOre() {
        if (!(level() instanceof ServerLevel serverLevel)) return;
        BlockPos origin = blockPosition();
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;

        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-3, -2, -3), origin.offset(3, 2, 3))) {
            BlockState state = level().getBlockState(pos);
            if (!isOre(state.getBlock())) continue;
            boolean exposed = false;
            for (Direction direction : Direction.values()) {
                if (level().getBlockState(pos.relative(direction)).isAir()) {
                    exposed = true;
                    break;
                }
            }
            if (!exposed || !level().getBlockState(pos.above()).isAir()) continue;
            double dist = pos.distToCenterSqr(position());
            if (dist < bestDistance) {
                bestDistance = dist;
                best = pos.immutable();
            }
        }

        if (best == null || bestDistance > 16.0) return;
        BlockState state = serverLevel.getBlockState(best);
        if (state.getDestroySpeed(level(), best) < 0) return;

        // Keep ore mining conservative: only ores with an exposed top and within arm's reach.
        List<ItemStack> drops = Block.getDrops(state, serverLevel, best, level().getBlockEntity(best), this, ItemStack.EMPTY);
        serverLevel.destroyBlock(best, false, this);
        for (ItemStack drop : drops) {
            if (!drop.isEmpty()) {
                ItemStack copy = drop.copy();
                insertStack(copy);
                if (!copy.isEmpty()) Block.popResource(serverLevel, best, copy);
            }
        }
        serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER,
                best.getX() + 0.5, best.getY() + 0.5, best.getZ() + 0.5, 5, 0.2, 0.2, 0.2, 0.0);
    }

    private static boolean isOre(Block block) {
        return block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE
                || block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE
                || block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE
                || block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE
                || block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE
                || block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE
                || block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE
                || block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE
                || block == Blocks.NETHER_GOLD_ORE || block == Blocks.NETHER_QUARTZ_ORE
                || block == Blocks.ANCIENT_DEBRIS;
    }

    private void trySleepBesideOwner() {
        if (owner == null || !owner.isSleeping() || sleepingBesideOwner || !(level() instanceof ServerLevel serverLevel)) return;
        BlockPos ownerBed = owner.getSleepingPos().orElse(null);
        if (ownerBed == null) return;

        // Find an empty adjacent space where a second bed can fit, then place a matching bed
        // only if the spot is already prepared with two air blocks and solid support.
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            BlockPos foot = ownerBed.relative(direction, 2);
            BlockPos head = foot.relative(direction);
            if (!level().getBlockState(foot).isAir() || !level().getBlockState(head).isAir()) continue;
            if (!level().getBlockState(foot.below()).isSolid() || !level().getBlockState(head.below()).isSolid()) continue;

            // A placed bed has orientation and two-block state requirements; use a vanilla bed item
            // placement simulation only where possible. We avoid silently changing blocks here.
            // Instead, Hitori sleeps beside the player's bed on the prepared two-block space.
            getNavigation().stop();
            getNavigation().moveTo(foot.getX() + 0.5, foot.getY(), foot.getZ() + 0.5, 1.0);
            if (distanceToSqr(foot.getX() + 0.5, foot.getY(), foot.getZ() + 0.5) < 2.25) {
                sleepingBesideOwner = true;
                sleepBedPos = foot.immutable();
                setDeltaMovement(0, 0, 0);
                setPose(net.minecraft.world.entity.Pose.SLEEPING);
                return;
            }
        }
    }

    private void wakeFromBed() {
        sleepingBesideOwner = false;
        sleepBedPos = null;
        setPose(net.minecraft.world.entity.Pose.STANDING);
    }

    public List<ItemStack> getCompanionInventory() {
        return List.copyOf(companionInventory);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        ListTag items = new ListTag();
        for (int i = 0; i < companionInventory.size(); i++) {
            ItemStack stack = companionInventory.get(i);
            if (!stack.isEmpty()) {
                CompoundTag itemTag = new CompoundTag();
                itemTag.putInt("Slot", i);
                items.add(stack.save(level().registryAccess(), itemTag));
            }
        }
        tag.put("BocchiInventory", items);
        tag.putBoolean("SleepingBesideOwner", sleepingBesideOwner);
        if (owner != null) tag.putUUID("OwnerUUID", owner.getUUID());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        for (int i = 0; i < companionInventory.size(); i++) companionInventory.set(i, ItemStack.EMPTY);
        ListTag items = tag.getList("BocchiInventory", Tag.TAG_COMPOUND);
        for (int i = 0; i < items.size(); i++) {
            CompoundTag itemTag = items.getCompound(i);
            int slot = itemTag.getInt("Slot");
            if (slot >= 0 && slot < companionInventory.size()) {
                companionInventory.set(slot, ItemStack.parse(level().registryAccess(), itemTag).orElse(ItemStack.EMPTY));
            }
        }
        sleepingBesideOwner = tag.getBoolean("SleepingBesideOwner");
        if (tag.hasUUID("OwnerUUID") && level() instanceof ServerLevel serverLevel) {
            serverLevel.getServer().getPlayerList().getPlayer(tag.getUUID("OwnerUUID"));
        }
    }

    private static class FollowOwnerGoal extends net.minecraft.world.entity.ai.goal.Goal {
        private final HitoriEntity hitori;
        private final double speed;
        private final float startDistance;
        private final float stopDistance;
        private int recalcDelay;

        FollowOwnerGoal(HitoriEntity hitori, double speed, float startDistance, float stopDistance) {
            this.hitori = hitori;
            this.speed = speed;
            this.startDistance = startDistance;
            this.stopDistance = stopDistance;
        }

        @Override
        public boolean canUse() {
            return hitori.owner != null && hitori.owner.isAlive()
                    && hitori.distanceToSqr(hitori.owner) > startDistance * startDistance;
        }

        @Override
        public boolean canContinueToUse() {
            return hitori.owner != null && hitori.owner.isAlive()
                    && hitori.distanceToSqr(hitori.owner) > stopDistance * stopDistance;
        }

        @Override
        public void tick() {
            if (hitori.owner == null) return;
            if (--recalcDelay <= 0) {
                recalcDelay = 10;
                hitori.getNavigation().moveTo(hitori.owner, speed);
            }
        }
    }
}
