package dev.bocchi.companion.client;

import dev.bocchi.companion.BocchiCompanion;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

public final class BocchiCompanionClient implements ClientModInitializer {
    public static final ModelLayerLocation HITORI_LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath(BocchiCompanion.MOD_ID, "hitori"), "main");

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(HITORI_LAYER, HitoriModel::createLayer);
        EntityRendererRegistry.register(BocchiCompanion.HITORI, HitoriRenderer::new);
    }
}
