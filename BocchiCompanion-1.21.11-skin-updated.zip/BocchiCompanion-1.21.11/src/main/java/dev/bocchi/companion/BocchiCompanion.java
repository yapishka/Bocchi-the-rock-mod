package dev.bocchi.companion;

import dev.bocchi.companion.entity.HitoriEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class BocchiCompanion implements ModInitializer {
    public static final String MOD_ID = "bocchi_companion";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final EntityType<HitoriEntity> HITORI = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(MOD_ID, "hitori")),
            EntityType.Builder.of(HitoriEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.75F)
                    .clientTrackingRange(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(MOD_ID, "hitori")))
    );

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(HITORI, HitoriEntity.createAttributes());
        // Spawn a companion for each player once when they first enter a world.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            Player player = handler.player;
            if (!(player.level() instanceof ServerLevel level)) return;
            if (player.getPersistentData().getBoolean("bocchi_companion_spawned")) return;
            HitoriEntity hitori = HITORI.create(level);
            if (hitori == null) return;
            hitori.moveTo(player.getX() + 1.5, player.getY(), player.getZ() + 1.5, player.getYRot(), 0.0F);
            level.addFreshEntity(hitori);
            player.getPersistentData().putBoolean("bocchi_companion_spawned", true);
        });
        LOGGER.info("Bocchi Companion initialized.");
    }
}
